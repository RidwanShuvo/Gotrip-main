
import Error from "./Error";

import {
  Route,
  RouterProvider,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import RootLayout from "./components/RootLayout";
import Home from "./components/pages/Home";
import Shop from "./components/pages/Shop";
import Signup from "./components/Signup";



function App() {
  // Router Path
  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route>
        <Route path="/" element={<RootLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/sign-up" element={<Signup/>} />

          <Route path="*" element={<Error />} />
        </Route>
      </Route>
    )
  );
  // Router Path
  return (
    <>
      
      <RouterProvider router={router} />


    </>
  );
}

export default App;
